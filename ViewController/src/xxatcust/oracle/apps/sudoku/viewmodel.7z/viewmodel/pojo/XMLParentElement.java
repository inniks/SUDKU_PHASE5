package xxatcust.oracle.apps.sudoku.viewmodel.pojo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


public class XMLParentElement {
    V93kQuote v93QuoteObject;
    public XMLParentElement() {
        super();
    }

    public void setV93QuoteObject(V93kQuote v93QuoteObject) {
        this.v93QuoteObject = v93QuoteObject;
    }
   
    public V93kQuote getV93QuoteObject() {
        return v93QuoteObject;
    }
}
