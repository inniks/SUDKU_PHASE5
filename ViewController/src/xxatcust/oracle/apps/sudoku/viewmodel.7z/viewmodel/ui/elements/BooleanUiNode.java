package xxatcust.oracle.apps.sudoku.viewmodel.ui.elements;


public class BooleanUiNode {
    public BooleanUiNode() {
        super();
    }

    ConfiguratorUiNode configuratorUiNode = null;

    public void setConfiguratorUiNode(ConfiguratorUiNode configuratorUiNode) {
        this.configuratorUiNode = configuratorUiNode;
    }

    public ConfiguratorUiNode getConfiguratorUiNode() {
        return configuratorUiNode;
    }

}
