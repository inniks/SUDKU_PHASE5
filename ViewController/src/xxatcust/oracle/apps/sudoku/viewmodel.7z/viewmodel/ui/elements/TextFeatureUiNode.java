package xxatcust.oracle.apps.sudoku.viewmodel.ui.elements;

public class TextFeatureUiNode {
    public TextFeatureUiNode() {
        super();
    }
}
