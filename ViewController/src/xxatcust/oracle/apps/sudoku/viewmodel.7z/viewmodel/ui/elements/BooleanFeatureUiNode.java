package xxatcust.oracle.apps.sudoku.viewmodel.ui.elements;

public class BooleanFeatureUiNode {
    public BooleanFeatureUiNode() {
        super();
    }
    ConfiguratorUiNode uiNode = null;

    public void setUiNode(ConfiguratorUiNode uiNode) {
        this.uiNode = uiNode;
    }

    public ConfiguratorUiNode getUiNode() {
        return uiNode;
    }

}
