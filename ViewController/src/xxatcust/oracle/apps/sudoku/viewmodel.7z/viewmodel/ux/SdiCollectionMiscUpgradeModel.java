package xxatcust.oracle.apps.sudoku.viewmodel.ux;

import java.util.ArrayList;

public class SdiCollectionMiscUpgradeModel {
    private String index;
    private ArrayList<ShowDetailItemCollection> sdiCollection ;
    private String subGrpName ;
    public SdiCollectionMiscUpgradeModel() {
        super();
    }

    public SdiCollectionMiscUpgradeModel(String index,
                                         ArrayList<ShowDetailItemCollection> sdiCollection,
                                         String subGrpName) {
        super();
        this.index = index;
        this.sdiCollection = sdiCollection;
        this.subGrpName = subGrpName;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getIndex() {
        return index;
    }

    public void setSdiCollection(ArrayList<ShowDetailItemCollection> sdiCollection) {
        this.sdiCollection = sdiCollection;
    }

    public ArrayList<ShowDetailItemCollection> getSdiCollection() {
        return sdiCollection;
    }

    public void setSubGrpName(String subGrpName) {
        this.subGrpName = subGrpName;
    }

    public String getSubGrpName() {
        return subGrpName;
    }
}
